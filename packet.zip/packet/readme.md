# Interview Packet

## Thank you!
First, I want to reach out and thank you for applying for a web development position at the Church of Jesus Christ of Latter-day Saints! Good luck as you accomplish the tasks below.

### The Tasks
In the folder we sent there are two files in the comps folder, Please code them up, they are Article and Tile.

## Instructions for the tasks
There are a few things to do:
* Create a repo in github or bitbucket to do your work in.
* Use the spec sheet in the comps folder for details you may need, if there is something missing feel free to email questions.
* Create a tag after you have developed for 1hr called 1hr.
* When you finish email us a link to your repo.

In the Folder there are several assets that are needed for different tasks. There is text to enter and images to use. We are not worried about which images go where, or what text is used. In fact, if you need one, http://dustinsenos.com/littleIpsum, is a great lorem ipsum generator for the mac and all the images are from unsplash. The font used, open sans, is a google font that you can find here: https://fonts.google.com/specimen/Open+Sans?selection.family=Open+Sans.

Please keep in mind as you are coding these tasks that we are an enterprise level development team and need to be thinking about maintainability, sharability, and footprint. Initial load as well as overall page size is important.

## Good Luck!
